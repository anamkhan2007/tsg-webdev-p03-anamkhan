(function () {
  "use strict";

  var header = document.querySelector(".site-header");
  var lastY = 0;

  function onScroll() {
    var y = window.scrollY || window.pageYOffset;
    if (y > 12) {
      header.classList.add("is-scrolled");
    } else {
      header.classList.remove("is-scrolled");
    }
    lastY = y;
  }

  window.addEventListener("scroll", onScroll, { passive: true });
  onScroll();

  var toggle = document.querySelector(".nav-toggle");
  var menu = document.querySelector(".mobile-menu");

  function closeMenu() {
    if (!toggle || !menu) return;
    toggle.classList.remove("is-open");
    menu.classList.remove("is-open");
    document.body.style.overflow = "";
    toggle.setAttribute("aria-expanded", "false");
  }

  function openMenu() {
    if (!toggle || !menu) return;
    toggle.classList.add("is-open");
    menu.classList.add("is-open");
    document.body.style.overflow = "hidden";
    toggle.setAttribute("aria-expanded", "true");
  }

  if (toggle && menu) {
    toggle.addEventListener("click", function () {
      if (toggle.classList.contains("is-open")) {
        closeMenu();
      } else {
        openMenu();
      }
    });

    menu.querySelectorAll("a").forEach(function (link) {
      link.addEventListener("click", closeMenu);
    });

    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape") closeMenu();
    });
  }

  var reveals = document.querySelectorAll(".reveal");
  if ("IntersectionObserver" in window && reveals.length) {
    var io = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            entry.target.classList.add("is-in");
            io.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.14, rootMargin: "0px 0px -40px 0px" }
    );
    reveals.forEach(function (el) {
      io.observe(el);
    });
  } else {
    reveals.forEach(function (el) {
      el.classList.add("is-in");
    });
  }

  var yearEls = document.querySelectorAll("[data-year]");
  yearEls.forEach(function (el) {
    el.textContent = new Date().getFullYear();
  });

  var forms = document.querySelectorAll("form[data-validate]");
  forms.forEach(function (form) {
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      var valid = true;
      form.querySelectorAll("[required]").forEach(function (field) {
        if (!field.value.trim()) {
          valid = false;
          field.style.borderColor = "#b5453b";
        } else {
          field.style.borderColor = "";
        }
      });
      var email = form.querySelector('input[type="email"]');
      if (email && email.value) {
        var re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!re.test(email.value)) {
          valid = false;
          email.style.borderColor = "#b5453b";
        } else {
          email.style.borderColor = "";
        }
      }
      if (!valid) return;

      var success = form.querySelector(".form-success");
      if (success) {
        success.classList.add("is-visible");
        success.scrollIntoView({ behavior: "smooth", block: "center" });
      }
      form.reset();
      setTimeout(function () {
        if (success) success.classList.remove("is-visible");
      }, 6000);
    });
  });

  var footForm = document.querySelector(".footer__newsletter");
  if (footForm) {
    footForm.addEventListener("submit", function (e) {
      e.preventDefault();
      var input = footForm.querySelector("input");
      if (input) input.value = "";
      var btn = footForm.querySelector("button");
      if (btn) {
        btn.setAttribute("aria-label", "Subscribed");
        btn.style.color = "#a8825a";
      }
    });
  }
})();
